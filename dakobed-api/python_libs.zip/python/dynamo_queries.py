import boto3

def transcriptions_query():
    return "from layer"