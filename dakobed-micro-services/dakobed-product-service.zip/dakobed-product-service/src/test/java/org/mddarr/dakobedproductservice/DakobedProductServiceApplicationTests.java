package org.mddarr.dakobedproductservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DakobedProductServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
